package testcases.C610F_NAMEMETHOD;

public class C610F_NAMEMETHOD__simple_01 {
    // 메소드의 접두사가 동사가 아닐 경우
    public void computerMonitor(){

    }
}

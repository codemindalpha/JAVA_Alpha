package testcases.C6110_NAMENOUSE;

public class C6110_NAMENOUSE__simple_01 {
    public void bad(){
/*        String this;
        int new;
        String int;*/
    }
}

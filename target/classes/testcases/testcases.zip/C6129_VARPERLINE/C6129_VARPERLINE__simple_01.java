package testcases.C6129_VARPERLINE;

public class C6129_VARPERLINE__simple_01 {
    public void bad(){
        int a, b, c;
        int d = 1, e = 2, f = 3;
    }
}

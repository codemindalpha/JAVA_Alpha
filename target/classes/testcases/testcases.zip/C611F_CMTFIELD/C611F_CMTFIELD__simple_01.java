package testcases.C611F_CMTFIELD;

public class C611F_CMTFIELD__simple_01 {
    static class Person {
        String name;
        int age;

        Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

    }
}

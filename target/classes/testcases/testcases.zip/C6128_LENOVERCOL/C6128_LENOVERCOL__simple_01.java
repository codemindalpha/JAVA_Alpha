package testcases.C6128_LENOVERCOL;

public class C6128_LENOVERCOL__simple_01 {
    public void bad(){
        int [] sLen = new int[5];
        sLen[10] = 1;

        int [] bLen = new int[5];
        bLen[2] = 0;
    }
}

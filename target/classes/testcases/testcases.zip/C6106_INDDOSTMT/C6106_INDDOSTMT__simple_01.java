package testcases.C6106_INDDOSTMT;

public class C6106_INDDOSTMT__simple_01 {
    public void bad() {
        do
        {
            System.out.println("6106_INDDOSTMT 검출");
        }
        while(true);
    }
}
